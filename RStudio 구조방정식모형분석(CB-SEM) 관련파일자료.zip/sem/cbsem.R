test <- read.csv("test1.csv")
colnames(test)
str(test)

#필요한 패키지 인스톨 및 등록
#install.packages("lavaan")
#install.packages("semPlot")
#install.packages("semTools")
library(lavaan)
library(semPlot)
library(semTools)

#확인적요인분석(CFA: 1차CFA): 측정도구별(구성체계의 타당성)
#x(독립), m(매개), y(종속) <==== 잠재변수
#모형의 적합도를 확보
#요인적재량 => 타당성 확인
#반영지표(99%) reflective
#조형지표(1%) formative: AMOS프로그램은 불가능 (PLS)
x <- 'xa=~xa1+xa2+xa3+xa4+xa5
        xb=~xb1+xb2+xb3+xb4+xb5
        xc=~xc1+xc2+xc3+xc4+xc5'
fit <- cfa(x, data=test, se="robust.sem")

#적합도 확인
#적합지수
#기본: x2(p) > .05 : x2값은 표본수에 민감하여 CFA적합도에서는 해석 X
#NC(Normed Chai square) x2/df <5 : 적합
#RMR < .05 / SRMR < .08
#RMSEA < .08
#AGFI > 0.8
#~~I > 0.9
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit))
#조금만 더 적합도를 개선시켜보자(판단)
#모형수정: 문항을 빼거나, 측정오차 간 공분산을 설정
#문항을 빼는 경우: 요인적재량 < 0.5 (타당성)
#  -동일 요인 내 측정오차 간 설정
#  -두 문항의 설문내용이 비슷하거나 다르거나

#요인적재량(factor loading) = 베타값 = 표준화계수
#summary(fit, standardized=T)
#아래와 같이 적합도와 요인적재량값을 한 번에 볼 수도 있음
summary(fit, fit.measure=TRUE, standardized=TRUE)

#수정지수(MI) 확인 : xa4~~xa5
modindices(fit)

#모형수정
x.mod <- 'xa=~xa1+xa2+xa3+xa4+xa5
        xb=~xb1+xb2+xb3+xb4+xb5
        xc=~xc1+xc2+xc3+xc4+xc5
           xa4~~xa5'
fit.mod <- cfa(x.mod, data=test, se="robust.sem")
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit.mod))
#summary(fit.mod, standardized=T)
#아래와 같이 적합도와 요인적재량값을 한 번에 볼 수도 있음
summary(fit.mod, fit.measure=TRUE, standardized=TRUE)

#결론: x에 대한 확인적 요인분석 결과
#적합도: 적합(xa4~~xa5 측정오차 간 공분산 설정: 모형수정)
#타당성: 모든 문항의 요인적재량 > 0.5

#모형 확인
semPlot::semPaths(fit.mod, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")

#사례1: 만약에 xb5문항의 요인적재량값이 0.5미만으로 나왔을 경우의 모형수정
x.mod2 <- 'xa=~xa1+xa2+xa3+xa4+xa5
        xb=~xb1+xb2+xb3+xb4
        xc=~xc1+xc2+xc3+xc4+xc5
           xa4~~xa5'
fit.mod2 <- cfa(x.mod2, data=test, se="robust.sem")
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit.mod2))
#summary(fit.mod2, standardized=T)
#아래와 같이 적합도와 요인적재량값을 한 번에 볼 수도 있음
summary(fit.mod2, fit.measure=TRUE, standardized=TRUE)
semPlot::semPaths(fit.mod2, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")

#사례2: 만약에 공분산을 2개 동시에 설정한다면
x.mod3 <- 'xa=~xa1+xa2+xa3+xa4+xa5
        xb=~xb1+xb2+xb3+xb4+xb5
        xc=~xc1+xc2+xc3+xc4+xc5
           xa4~~xa5
           xb2~~xb3'
fit.mod3 <- cfa(x.mod3, data=test, se="robust.sem")
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit.mod3))
#summary(fit.mod3, standardized=T)
#아래와 같이 적합도와 요인적재량값을 한 번에 볼 수도 있음
summary(fit.mod3, fit.measure=TRUE, standardized=TRUE)
semPlot::semPaths(fit.mod3, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")

#사례3: 단일지표
x.mod4 <- 'xa=~xa1+xa2+xa3+xa4+xa5
        xb=~xb1+xb2+xb3+xb4+xb5
        xc=~xc1
           xa4~~xa5
           xb2~~xb3'
fit.mod4 <- cfa(x.mod4, data=test, se="robust.sem")
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit.mod4))
#summary(fit.mod4, standardized=T)
#아래와 같이 적합도와 요인적재량값을 한 번에 볼 수도 있음
summary(fit.mod4, fit.measure=TRUE, standardized=TRUE)
semPlot::semPaths(fit.mod4, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")
#AMOS프로그램: 단일지표의 경우는 측정오차의 분산값을 고정(1-크롬바알파값) => 조정
#조정하는 이유: 요인적재량값을 0.5보다 크게 하기 위해서

#사례4: 한 요인에 문항이 2개인데, 이 2개의 측정오차 간 공분산 설정
#AMOS에서는 불가능
x.mod5 <- 'xa=~xa1+xa2+xa3+xa4+xa5
        xb=~xb1+xb2+xb3+xb4+xb5
        xc=~xc1+xc2
           xa4~~xa5
           xb2~~xb3'
fit.mod5 <- cfa(x.mod5, data=test, se="robust.sem")
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit.mod5))
#summary(fit.mod5, standardized=T)
#아래와 같이 적합도와 요인적재량값을 한 번에 볼 수도 있음
summary(fit.mod5, fit.measure=TRUE, standardized=TRUE)
semPlot::semPaths(fit.mod5, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")

#변수계산(차원감소): 평균화
xaa = (test$xa1+test$xa2+test$xa3+test$xa4+test$xa5)/5
test <- cbind(test, xaa)
colnames(test)

#기술통계분석(최소값, 최대값, 평균, 표준편차, 정규성(왜도, 첨도))
test1 <- test[c(50:58)]
summary(test1)
mean(test1$xa)
sd(test1$xa)
#install.packages("moments")
library(moments)
colnames(test1)
sk <- skewness(test1[, c(1:9)], na.rm=T)
kt <- kurtosis(test1[, c(1:9)], na.rm=T)
skkt <- cbind(sk, kt)
round(skkt, 3)
#정규성 기준: 왜도<절대값2, 첨도<절대값4
#이상치 검사: 사분위수=> IQR*1.5 => 이상치 제거 => 새로운 데이터
fivenum(test1$xa[2]-1.5*IQR(test1$xa))
fivenum(test1$xa[4]+1.5*IQR(test1$xa))
test1$xa <- ifelse(test1$xa<3.5, NA, test1$xa)
test1$xa <- ifelse(test1$xa>6.5, NA, test1$xa)
test2 <- na.omit(test1)
#다시 정규성 검사
sk1 <- skewness(test2[, c(1:9)], na.rm=T)
kt1 <- kurtosis(test2[, c(1:9)], na.rm=T)
skkt1 <- cbind(sk1, kt1)
round(skkt1, 3)
#shapiro.test()사용해서 xa변수에 대한 정규성 검사 p> 0.05
shapiro.test(test2$xa)
x <- rnorm(241)
qqnorm(x)
qqline(x)
qqnorm(test2$xa)
qqline(test2$xa)
shapiro.test(x)

#1차CFA => 변수계산(평균화) => 측정변수생성 => 정규성, 이상치
#test2라는 데이터 생성 (270 => 241, 29개의 샘플이 제거)
#2차CFA 생략
#측정모형분석=측정모델분석=확인적요인분석 (3차CFA)
colnames(test2)
xmy <- 'x=~xa+xb+xc
        m=~ma+mb+mc+md
        y=~ya+yb'
xmy.fit <- cfa(xmy, data=test2, se="robust.sem")
#lavaan:::print.lavaan.fitMeasures(fitMeasures(xmy.fit))
#summary(xmy.fit, standardized=T)
#아래와 같이 적합도와 요인적재량값을 한 번에 볼 수도 있음
summary(xmy.fit, fit.measure=TRUE, standardized=TRUE)
inspect(xmy.fit, "rsquare")
reliability(xmy.fit)
cor <- inspect(xmy.fit, "cor.lv")
sqr_ave <- as.data.frame(sqrt(reliability(xmy.fit)[5, -4]))
colnames(sqr_ave) <- "SQRT_AVE"
cbind(cor, sqr_ave)
semPlot::semPaths(xmy.fit, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")
#측정모델에서는 모형수정이 일어날 경우: 이론적 근거 제시
#측정모델은 가급적이면 한 번에 적합도가 나와야 하고, 모형수정 가급적이면 X
#따라서, 측정모델 전에 1차CFA에서 최선을 다해서 타당성을 확보
#구조방정식모형 가설설정 : 1차CFA(최대우도법)->측정모델(최대우도법)
#                          ------------------
#                          주성분법(SPSS)

#구조방정식모델 분석(x===>M===>Y) : 단순매개모형 (간접효과 있음)

#구조모델분석: test2 (이상치가 제거된 9개의 측정변수만으로 구성)
xmy.sem <- 'x=~xa+xb+xc
            m=~ma+mb+mc+md
            y=~ya+yb
              m~a*x
              y~b*m+c*x
              indirect effect:=a*b
              total effect:=c+(a*b)'
fit.sem <- sem(xmy2.sem, data=test2, se="bootstrap", bootstrap=200L)
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit.sem))
#summary(fit.sem, standardized=T)
#아래와 같이 적합도와 영향력을을 한 번에 볼 수도 있음
summary(fit.sem, fit.measure=TRUE, standardized=TRUE)
inspect(fit.sem, "rsquare")
semPlot::semPaths(fit.sem, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")

#구조모델: 이중매개(병렬구조)
xmy2.sem <- 'x=~xa+xb+xc
            m1=~ma+mb
            m2=~mc+md
            y=~ya+yb
              m1~a1*x
              m2~a2*x
              y~c*x+b1*m1+b2*m2
              ind1:=a1*b1
              ind2:=a2*b2
              ind3:=(a1*b1)+(a2*b2)
              total effect:=c+(a1*b1)+(a2*b2)'
fit2.sem <- sem(xmy2.sem, data=test2, se="bootstrap", bootstrap=200L)
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit2.sem))
#summary(fit2.sem, standardized=T)
#아래와 같이 적합도와 영향력을을 한 번에 볼 수도 있음
summary(fit2.sem, fit.measure=TRUE, standardized=TRUE)
inspect(fit2.sem, "rsquare")
semPlot::semPaths(fit2.sem, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")

#구조모델: 이중매개(직렬구조)
xmy3.sem <- 'x=~xa+xb+xc
            m1=~ma+mb
            m2=~mc+md
            y=~ya+yb
              m1~a1*x
              m2~a2*x
              m2~b3*m1
              y~c*x+b1*m1+b2*m2
              ind1:=a1*b1
              ind2:=a2*b2
              ind3:=b3*b2
              ind4:=(a1*b1)+(a2*b2)+(b3*b2)
              total effect:=c+(a1*b1)+(a2*b2)+(b3*b2)'
fit3.sem <- sem(xmy3.sem, data=test2, se="bootstrap", bootstrap=200L)
#lavaan:::print.lavaan.fitMeasures(fitMeasures(fit3.sem))
#summary(fit3.sem, standardized=T)
#아래와 같이 적합도와 영향력을을 한 번에 볼 수도 있음
summary(fit3.sem, fit.measure=TRUE, standardized=TRUE)
inspect(fit3.sem, "rsquare")
semPlot::semPaths(fit3.sem, 
                  whatLabels="std", style="lisrel", 
                  nCharNodes=0, 
                  nCharEdges=0, 
                  layout="tree2")

#구조모델: 조절효과(등가제약-비제약모델)
#                   --------  ---------
#                    x2(df)  -   x2(df)  = x2(1) > 3.84 이면
#                                          교차타당성이 없다
#           비제약 걸었던 해당 경로에서집단 간 차이가 보인다
#           결국, 그 경로에서 조절효과가 있다.
#집단에 대한 분석
# -회귀모형: 조절변수=연속형변수
# -구조모형: 조절변수=집단변수(2집단)
#                     -> 원래 집단: 개인적배경(성별)
#                        조절효과의 경로-모든 경로
#                         -> 원래 2집단: 성별
#                         -> 원래 2집단X: 연령대->2집단
#                     -> 원래 연속형: 사회적지지
#                        논리적인 근거에 의해-> 조절 경로 제시
#                         -> 평균값: 저-고
#                         -> 하위25%(저)-상위25(고)  

#test2 데이터를 활용해서 조절효과분석을 해 봅시다.
colnames(test2)
#예) md를 조절변수로 선택해보자=>평균값=>저(1), 고(2)=>mds집단변수 생성
mds <- test2$md
test2 <- cbind(test2, mds)
summary(test2$mds)
test2$mds <- ifelse(test2$mds<3.004, 1, test2$mds)
test2$mds <- ifelse(test2$mds>=3.004, 2, test2$mds)

#등가제약모델: 단순매개의 형태 x->m->y
cd.sem <- 'x=~xa+xb
           m=~ma+mb
           y=~ya+yb
                m~x
                y~m+x'
fitcd.sem <- sem(cd.sem, data=test2, group="mds", group.equal=c("loadings", "intercepts", "regressions"))
summary(fitcd.sem, fit.measure=TRUE, standardized=TRUE)
#등가제약모델의 x2(df) = 66.515(21)

#비제약모델: y~x
cb.sem <- 'x=~xa+xb
           m=~ma+mb
           y=~ya+yb
                m~x
                y~m+x'
fitcb.sem <- sem(cb.sem, data=test2, group="mds", group.equal=c("loadings", "intercepts", "regressions"),
                 group.partial=c("y~x"))
summary(fitcb.sem, fit.measure=TRUE, standardized=TRUE)
#비제약모델(y~x)의 x2(df) = 66.158(20)

#조절효과 : 두 모델의 x2차이 diff.x2(1)=66.515-66.158<3.84이기 때문에, p>0.05 ===> 집단 간 차이가 X ==> 조절효과X
